﻿using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Linq;
using System.Net;
using TechTalk.SpecFlow;

namespace Happy_Holidays_Test
{
    [Binding]
    public class FirstTestSteps
    {
        Stream stream;

        public void ReadJSON()
        {
            //assuming the API works and is secure
            string url = "api.openweathermap.org/data/2.5/forecast/daily?id=524901";
            //create a HTTP web request for the API
            HttpWebRequest httpWebRequest = WebRequest.Create(url) as HttpWebRequest;
            //specify the JSON format
            httpWebRequest.ContentType = "application/json; charset=utf-8";

            //Get the web response
            using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
            {
                //Check if JSON response is valid
                if (httpWebResponse.StatusCode != HttpStatusCode.OK)
                {
                    //throw an exception if response is invalid
                    throw new Exception(string.Format("Server error (HTTP {0}: {1}).",
                        httpWebResponse.StatusCode, httpWebResponse.StatusDescription));
                }

                //copy the entire API response string into the variable "stream"
                stream = httpWebResponse.GetResponseStream();
            }
        }

        [Given(@"I like to holiday in Sydney")]
        public void GivenILikeToHolidayInSydney()
        {
            //assuming city ID for Sydney
            int Sydney = 123456;
            dynamic jsonData = JObject.Parse(stream.ToString());
            //check if the city ID in the JSON response matches Sydney
            if (jsonData.city.id == Sydney)
            {
                Console.WriteLine("Yaay!! Sydney it is!");
            }
        }
        
        [Given(@"I only like to holiday on Thursdays")]
        public void GivenIOnlyLikeToHolidayOnThursdays()
        {
            //assuming day ID, which isn't provided in the JSON response
            int Thursday = 123456;
            dynamic jsonData = JObject.Parse(stream.ToString());
            //check if the day ID in the JSON response matches Sydney
            if (jsonData.day.id == Thursday)
            {
                Console.WriteLine("Yaay!! Thursday it is!");
            }
        }
        
        [When(@"I look up the weather forecast")]
        public void WhenILookUpTheWeatherForecast()
        {
            Console.WriteLine("Looking up the weather forecast...");
        }
        
        [Then(@"I receive the weather forecast")]
        public void ThenIReceiveTheWeatherForecast()
        {
            Console.WriteLine("Weather forecast for the next 16 days was pulled out for you!");
        }

        [Then(@"the temperature is warmer than (.*) degrees")]
        public void ThenTheTemperatureIsWarmerThanDegrees(int p0)
        {
            //Convert degree celsius to kelvin, as the JSON returns temperatures in kelvin
            float tempInKelvin = (float)(p0 + 273.15);
            dynamic jsonData = JObject.Parse(stream.ToString());
            //check if the city ID in the JSON response matches Sydney
            if (jsonData.list.temp.day > tempInKelvin)
            {
                Console.WriteLine("Yaay!! It's a warm day!");
                Console.WriteLine("You have a perfect day for an awesome Holiday!");
            }
        }
    }
}
